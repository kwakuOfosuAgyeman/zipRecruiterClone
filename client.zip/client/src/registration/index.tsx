import React from 'react';


const index = () => {
  return (
    <div> 
       <h1>Registration</h1>
    </div>
  )
}

export default index;