import React from 'react';
import Navbar from '../components/navbar';


const index = () => {
  return (
    <div>
      <Navbar />
     <div className='container mx-auto'>
      <div>
        <h1>Sign Up</h1>
        <p>Please create your account</p>
      </div>
     </div>
    </div>
  )
}

export default index;