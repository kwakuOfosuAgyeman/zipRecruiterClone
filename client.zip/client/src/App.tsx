import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Routes, Route} from "react-router-dom";

import Login from "../src/login/index";
import Registration from "../src/registration/index"

function App() {

  
  return (
    // <div className="App">
       <Routes>
          <Route path="/login" element={<Login />}/>
          <Route path="/registration" element={<Registration/>}/>
        </Routes>
    // </div>
  );
}

export default App;
